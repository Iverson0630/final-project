
var ws = require("nodejs-websocket");
var xy;
const net = require("net");
var flag=0;
let fs = require('fs');
let path = require('path');
let str_audio = path.join(__dirname, "tmp.wav");
let writeStream1 = fs.createWriteStream(str_audio,{
    channels: 2,
    sampleRate: 44100,
    bitDepth: 16
});

var listenPort = 8081;//监听端口
var server = net.createServer(function(socket){
    // 创建socket服务端
    console.log('connect: ' +
        socket.remoteAddress + ':' + socket.remotePort);
        console.log('手机端APP连接成功')
    //接收到数据
    socket.on('data',function(data) {
        console.log('client send:' +data.length);
        flag = 1;
        if(data.length<40){
            let str_xy = path.join(__dirname, "tmp.txt");
            let writeStream2 = fs.createWriteStream(str_xy);
            writeStream2.write(data);
            xy = data;
            console.log('client send:' +data);}
        else{
            console.log('开始传输录音');
            writeStream1.write(data);
            console.log('录音已保存至本地');}
    })
    //数据错误事件
    socket.on('error',function(exception){
        console.log('data error:' + exception);
        socket.end();
    });
    //客户端关闭事件
    socket.on('close',function(data){
        console.log('client closed!');
        // socket.remoteAddress + ' ' + socket.remotePort);
    });
}).listen(listenPort);
//服务器监听事件
server.on('listening',function(){
    console.log("server listening:" + server.address().port);
});
//服务器错误事件
server.on("error",function(exception){
    console.log("server error:" + exception);
});

var server1 = ws.createServer(function(connect) { //创建一个新连接
    console.log('html客户端已连接！');
    if(flag>0){
        console.log('开始发送经纬度');
          connect.send('开始发送经纬度');
          connect.send(xy);
    }
}).listen(8084);