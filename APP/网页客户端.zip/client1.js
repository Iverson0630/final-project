
//引用的应该是socket.io-client;
const io = require('socket.io-client');
//connect函数可以接受一个url参数，url可以socket服务的http完整地址，也可以是相对路径，如果省略则表示默认连接当前路径。
// 与服务端类似，客户端也需要注册相应的事件来捕获信息，不同的是客户端连接成功的事件是connect。
const socket = io('http://jmb.ifast3.vipnps.vip');
//const socket = io('http://172.18.232.84:5000');
socket.on('connect', function () {
    console.log('connect successed');
});
//socket失去连接时触发（包括关闭浏览器，主动断开，掉线等任何断开连接的情况）
socket.on('disconnect',function(){
    console.log("server disconnect");
})

//发送base64格式图片
socket.emit("png0","");

socket.on('server', function (data) {
    console.log(data);
});

socket.on('sendMsgA',data => sendMessage(data));

function sendMessage(data) {
    console.log(data);
}

//发送轨迹 1，2交替发送

//1
// socket.emit("pos1",JSON.stringify({id:0,frame_index:1,pos_x:2,pos_y:-0.5,predict_x:8.00,predict_y:0.20}))
// socket.emit("pos1",JSON.stringify({id:1,frame_index:1,pos_x:2.5,pos_y:0,predict_x:5.00,predict_y:0.30}))
// socket.emit("pos1",JSON.stringify({id:0,frame_index:1,pos_x:3,pos_y:0.1,predict_x:2.44,predict_y:0.55}))
// socket.emit("pos1",JSON.stringify({id:1,frame_index:1,pos_x:3.5,pos_y:0.5,predict_x:8.00,predict_y:-1.00}))
// socket.emit("pos1",JSON.stringify({id:0,frame_index:1,pos_x:1,pos_y:0.2,predict_x:3.00,predict_y:-1.30}))
// socket.emit("pos1",JSON.stringify({id:1,frame_index:1,pos_x:4,pos_y:0.9,predict_x:4.55,predict_y:-2.80}))

//2
socket.emit("pos1",JSON.stringify({id:0,frame_index:2,pos_x:2.8,pos_y:-0.5,predict_x:5,predict_y:1.2}))
socket.emit("pos1",JSON.stringify({id:1,frame_index:2,pos_x:5,pos_y:-0.8,predict_x:4.00,predict_y:0.10}))
socket.emit("pos1",JSON.stringify({id:0,frame_index:2,pos_x:3,pos_y:0.5,predict_x:5.44,predict_y:1.55}))
socket.emit("pos1",JSON.stringify({id:1,frame_index:2,pos_x:6,pos_y:-1.5,predict_x:6.30,predict_y:-1.00}))
socket.emit("pos1",JSON.stringify({id:0,frame_index:2,pos_x:4,pos_y:0.9,predict_x:4.30,predict_y:-1.40}))
socket.emit("pos1",JSON.stringify({id:1,frame_index:2,pos_x:1,pos_y:1.5,predict_x:5.50,predict_y:-2.80}))

