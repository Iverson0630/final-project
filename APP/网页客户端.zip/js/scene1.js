var objArray = new Array(); //位于handleData()中，建立对象数组，使每一帧信息打包整体显示
var frameIndex; //handleData()中存放帧数
//位于handleTrack()中，用于显示预测轨迹，predict_x，predict_y
//建立轨迹三维数组，以呈现不同物体分别的轨迹
//第一维为物体id序号，第二维为物体XY坐标，[data.id][0]放所有x坐标，[data.id][1]放所有y坐标
var dotArray =new Array();        //声明一维
for(let i=0;i<3;i++){         //假设一维长度为3,3个id
    dotArray[i]=new Array();
    for(let j=0;j<2;j++){     //二维长度为2,分别放x，y坐标
        dotArray[i][j]=new Array();
    }
}
var frameIndex_track; //handleTrack()中存放帧数
////位于handleTrack()中，用于显示历史轨迹，pos_x，post_y
var dotHistory =new Array();        //声明一维
for(let i=0;i<3;i++){         //假设一维长度为3,3个id
    dotHistory[i]=new Array();
    for(let j=0;j<2;j++){     //二维长度为2,分别放x，y坐标
        dotHistory[i][j]=new Array();
    }
}
var frameIndex_His;
var flagId = new Array();  //
//建立连接，端口为3000
var socket = io('http://127.0.0.1:3000', {transports:['websocket','xhr-polling','jsonp-polling']});  //增加第二参数解决跨域访问问题
socket.on('connect', () => {
    console.log("connect success");
});
socket.on('disconnect',() => {
    console.log("disconnect");
});
socket.on('sendMsgA',data => handleData(data));
socket.on('sendPicture0',data => handlePicture0(data));
socket.on('sendPicture1',data => handlePicture1(data));
socket.on('sendPicture2',data => handlePicture2(data));
socket.on('sendTrack',data => handleTrack(data));
socket.emit('report',"HTML客户端已连接")
function removeALl(element) {
    let div = document.getElementById(element);
    while (div.hasChildNodes()) {
        div.removeChild(div.children[0]);
    }
}
function handleData(data) {
    console.log("JSON原码：" + data);
    objArray.push(data);       //将对象信息存放在对象数组中
    console.log("frameIndex：" + data.frame_index);
    console.log("id：" + data.class_id);
    console.log("left：" + data.left);
    console.log("top：" + data.top);
    console.log("width：" + data.width);
    console.log("height：" + data.height)

    //判断一帧内容是否发送完毕，若发送完毕，打包显示上一帧内容
    if(data.frame_index !== frameIndex) {
        removeALl('block1_2');
        console.log("已清除!!!");
        for (let i=0; i<objArray.length; i++){
            console.log("对象数组长度："+objArray.length);
            showObject(objArray[i]);
        }
        objArray.splice(0,objArray.length);
        console.log("清空后长度："+objArray.length);
    }
    frameIndex = data.frame_index;

    function showObject(data_obj) {
        let object_div = document.createElement("object_div");
        let picture = null;
        switch (data_obj.class_id) {
            case 0:
                picture = "pictures/male.png";
                break
            case 2:
                picture = "pictures/car2.png";
                break
            case 5:
                picture = "pictures/bus.png";
                break
            case 7:
                picture = "pictures/truck2.png";
                break
            default:
        }
        let width = data_obj.width/10 + '%';
        let height = data_obj.height/8 + '%';
        let pos_x = data_obj.left/15 + '%';
        let pos_y = data_obj.top/10+20 + '%';

        // let width = data_obj.width + 'px';
        // let height = data_obj.height + 'px';
        // let pos_x = data_obj.left + 'px';
        // let pos_y = data_obj.top + 'px';
        // let deg = 'rotateZ(' + data_obj.deg + 'deg)';

        object_div.innerHTML = '<img class="object" style="width:'+width+';height:'+height+
            ';position:absolute;left:'+pos_x+';top:'+pos_y+';" src="'+picture+'">'
        document.getElementById("block1_2").appendChild(object_div);
    }
}
function handlePicture0(data) {
    console.log("Picture原码：" + data);
    let img = document.getElementById("img_base64");
    //将二进制流转换为base64格式
    // let img64 = window.btoa(new Uint8Array(data).reduce((data, byte) => data + String.fromCharCode(byte),''));
    // console.log(img64);
    // let pic = 'data:image/png;base64,'+img64;
    let pic = 'data:image/png;base64,'+data;
    img.setAttribute("src",pic);
}
function handlePicture1(data) {
    console.log("Picture1原码：" + data);
    let img = document.getElementById("img_base64_1");
    let pic = 'data:image/png;base64,'+data;
    img.setAttribute("src",pic);
}
function handlePicture2(data) {
    console.log("Picture2原码：" + data);
    let img = document.getElementById("img_base64_2");
    let pic = 'data:image/png;base64,'+data;
    img.setAttribute("src",pic);
}
function handleTrack(data) {
    //左上栏展示信息
    document.getElementById("FrameNumber1").innerHTML = "FrameNumber: "+data.frame_index;
    document.getElementById("Id1").innerHTML = "Object.Id: "+data.id;
    document.getElementById("Type1").innerHTML = "Class: person";
    document.getElementById("Pos_X1").innerHTML = "Pos_X: "+data.pos_x;
    document.getElementById("Pos_Y1").innerHTML = "Pos_Y: "+data.pos_y;

    //预测轨迹：
    // console.log("dotArray"+dotArray);
    //若帧数改变，将dotArray第二维数据清零，第一维id保留
    if(data.frame_index !== frameIndex_track){
        removeALl('block111');
        //将上一帧保存在数组中的所有数据发出
        for (let i=0;i<dotArray.length;i++){
            let dot1 = new Array();
            for (let j=0;j<dotArray[0][0].length;j++){
                showDot(dotArray[i][0][j],dotArray[i][1][j]);
                showLine(dotArray[i][0][j],dotArray[i][1][j],dot1);
            }
        }
        //清除数组
        for (let m=0;m<dotArray.length;m++){
            dotArray[m][0].splice(0);
            dotArray[m][1].splice(0);
        }
    }
    frameIndex_track = data.frame_index;
    //将预测轨迹数据存入数组
    dotArray[data.id][0].push((data.predict_x*40));
    dotArray[data.id][1].push((data.predict_y*40+400));

    //历史轨迹：
    //将将当前位置坐标存入数组dotHistory
    if(data.frame_index !== frameIndex_His){
        for (let i=0;i<20;i++){
            flagId[i]=0;
        }
    }
    if(flagId[data.id]==0){
        flagId[data.id] = 1;
        //坐标换算
        dotHistory[data.id][0].push((data.pos_x*40));
        dotHistory[data.id][1].push((data.pos_y*40+400));
    }
    frameIndex_His = data.frame_index;
    //历史轨迹超过二十个点时清除最远的点
    // console.log("dotHistory["+data.id+"][0].length:"+dotHistory[data.id][0].length);
    // console.log("x坐标"+dotHistory[data.id][0]);
    // console.log("y坐标"+dotHistory[data.id][1]);
    if (dotHistory[data.id][0].length>=25){
        dotHistory[data.id][0].splice(0,1);
        dotHistory[data.id][1].splice(0,1);
    }
    //打印数组中所有的点和轨迹
    for (let i=0;i<dotHistory.length;i++){
        let dot2 = new Array();
        for (let j=0;j<dotHistory[0][0].length;j++){
            showDot(dotHistory[i][0][j],dotHistory[i][1][j]);
            showLineHis(dotHistory[i][0][j],dotHistory[i][1][j],dot2);
        }
    }


}
function showDot(dot_x, dot_y) {
    let dotDiv = document.createElement("dotDiv");
    dotDiv.innerHTML = '<div class="dot1" style="width: 5px;height: 5px;border-radius:50%;background-color: red;' +
        'position: absolute;left:' + dot_x + 'px;bottom: ' + dot_y + 'px"></div>'
    document.getElementById("block111").appendChild(dotDiv);
}
function showLine(dot_x, dot_y,array) {
    var array = (typeof array!="object")? [array] : array  //确保参数总是数组
    console.log("array:"+array);
    //当数组长度大于等于4时，清空数组
    if (array.length >= 4) {
        array.splice(0, 2);
    }
    //将x、y添加到数组中,数组中保存了两组坐标值，相当于页面上的A(x1,y1)、B(x2,y2)两点
    array.push(dot_x, dot_y);
    //当数组长度为4时画线
    if (array.length == 4) {
        //计算div的长和宽
        let width = Math.abs(array[0] - array[2]);
        if (width < 1) width = 1;  //防止tan90度出bug
        let height = Math.abs(array[1] - array[3]);
        //在页面上定位div左下角的具体位置
        let left = array[0] - array[2] < 0 ? array[0] : array[2];
        let bottom = array[1] - array[3] < 0 ? array[1] : array[3];
        //计算两点间距离
        let distance = Math.sqrt((array[0] - array[2]) ** 2 + (array[1] - array[3]) ** 2);
        // console.log("distance:" + distance);
        //计算角度
        let degree = -Math.atan((array[3] - array[1]) / (array[2] - array[0])) / 2 / Math.PI * 360;
        //以相邻点为顶点建立一个块,并在块中画线
        let line_div = document.createElement("line_div");
        line_div.innerHTML =
            ' <div class="line_div" style="width:' + width + 'px;height:' + height + 'px;visibility:visible;' +
            'position:absolute;left:' + (left + 3) + 'px;bottom:' + (bottom) + 'px;transform:rotateZ(' + degree + 'deg);">' +
            ' <div class="line_div_div" style="width:' + distance + 'px;height:2px;background-color:#000000;' +
            'position:absolute;visibility:visible;left:' + (width - distance) / 2 / width * 100 + '%;bottom:50%;"></div>' +
            '</div>';
        document.getElementById("block111").appendChild(line_div);
    }
}
function showLineHis(dot_x, dot_y,array) {
    var array = (typeof array!="object")? [array] : array  //确保参数总是数组
    //当数组长度大于等于4时，清空数组
    if (array.length >= 4) {
        array.splice(0, 2);
    }
    //将x、y添加到数组中,数组中保存了两组坐标值，相当于页面上的A(x1,y1)、B(x2,y2)两点
    array.push(dot_x, dot_y);
    //当数组长度为4时画线
    if (array.length == 4) {
        //计算div的长和宽
        let width = Math.abs(array[0] - array[2]);
        if (width < 1) width = 1;  //防止tan90度出bug
        let height = Math.abs(array[1] - array[3]);
        //在页面上定位div左下角的具体位置
        let left = array[0] - array[2] < 0 ? array[0] : array[2];
        let bottom = array[1] - array[3] < 0 ? array[1] : array[3];
        //计算两点间距离
        let distance = Math.sqrt((array[0] - array[2]) ** 2 + (array[1] - array[3]) ** 2);
        // console.log("distance:" + distance);
        //计算角度
        let degree = -Math.atan((array[3] - array[1]) / (array[2] - array[0])) / 2 / Math.PI * 360;
        //以相邻点为顶点建立一个块,并在块中画线
        let line_div = document.createElement("line_div");
        line_div.innerHTML =
            ' <div class="line_div" style="width:' + width + 'px;height:' + height + 'px;visibility:visible;' +
            'position:absolute;left:' + (left + 3) + 'px;bottom:' + (bottom) + 'px;transform:rotateZ(' + degree + 'deg);">' +
            ' <div class="line_div_div" style="width:' + distance + 'px;height:2px;background-color:blue;' +
            'position:absolute;visibility:visible;left:' + (width - distance) / 2 / width * 100 + '%;bottom:50%;"></div>' +
            '</div>';
        document.getElementById("block111").appendChild(line_div);
    }
}