$(function () {

    // ceshis1();
    ceshis2();
    chart_rightBottom();
    chart_leftBottom();

    // function ceshis1() {
    //     var myChart = echarts.init(document.getElementById('chart2'));
    //
    //     var ydata = [{
    //         name: '天猫',
    //         value: 18
    //     },
    //         {
    //             name: '京东',
    //             value: 16
    //         },
    //         {
    //             name: '苏宁易购',
    //             value: 15
    //         },
    //         {
    //             name: '拼多多',
    //             value: 14
    //         },
    //         {
    //             name: '国美',
    //             value: 10
    //         },
    //         {
    //             name: '亚马逊',
    //             value: 7.9
    //         },
    //         {
    //             name: '唯品会',
    //             value: 6.7
    //         },
    //         {
    //             name: '其他',
    //             value: 6
    //         }
    //     ];
    //     var color = ["#8d7fec", "#5085f2", "#e75fc3", "#f87be2", "#f2719a", "#fca4bb", "#f59a8f", "#fdb301", "#57e7ec", "#cf9ef1"]
    //     var xdata = ['天猫', "京东", "苏宁易购", "拼多多", '国美', '亚马逊', '唯品会', '唯品会'];
    //
    //
    //     option = {
    //         /*backgroundColor: "rgba(255,255,255,1)",*/
    //         color: color,
    //         legend: {
    //             orient: "vartical",
    //             x: "left",
    //             top: "center",
    //             left: "53%",
    //             bottom: "0%",
    //             data: xdata,
    //             itemWidth: 8,
    //             itemHeight: 8,
    //             textStyle: {
    //                 color: '#fff'
    //             },
    //             /*itemGap: 16,*/
    //             /*formatter:function(name){
    //               var oa = option.series[0].data;
    //               var num = oa[0].value + oa[1].value + oa[2].value + oa[3].value+oa[4].value + oa[5].value + oa[6].value + oa[7].value+oa[8].value + oa[9].value ;
    //               for(var i = 0; i < option.series[0].data.length; i++){
    //                   if(name==oa[i].name){
    //                       return ' '+name + '    |    ' + oa[i].value + '    |    ' + (oa[i].value/num * 100).toFixed(2) + '%';
    //                   }
    //               }
    //             }*/
    //
    //             formatter: function(name) {
    //                 return '' + name
    //             }
    //         },
    //         series: [{
    //             type: 'pie',
    //             clockwise: false, //饼图的扇区是否是顺时针排布
    //             minAngle: 2, //最小的扇区角度（0 ~ 360）
    //             radius: ["20%", "60%"],
    //             center: ["30%", "45%"],
    //             avoidLabelOverlap: false,
    //             itemStyle: { //图形样式
    //                 normal: {
    //                     borderColor: '#ffffff',
    //                     borderWidth: 1,
    //                 },
    //             },
    //             label: {
    //                 normal: {
    //                     show: false,
    //                     position: 'center',
    //                     formatter: '{text|{b}}\n{c} ({d}%)',
    //                     rich: {
    //                         text: {
    //                             color: "#fff",
    //                             fontSize: 14,
    //                             align: 'center',
    //                             verticalAlign: 'middle',
    //                             padding: 8
    //                         },
    //                         value: {
    //                             color: "#8693F3",
    //                             fontSize: 24,
    //                             align: 'center',
    //                             verticalAlign: 'middle',
    //                         },
    //                     }
    //                 },
    //                 emphasis: {
    //                     show: true,
    //                     textStyle: {
    //                         fontSize: 24,
    //                     }
    //                 }
    //             },
    //             data: ydata
    //         }]
    //     };
    //     myChart.setOption(option);
    //
    //     setTimeout(function() {
    //         myChart.on('mouseover', function(params) {
    //             if (params.name == ydata[0].name) {
    //                 myChart.dispatchAction({
    //                     type: 'highlight',
    //                     seriesIndex: 0,
    //                     dataIndex: 0
    //                 });
    //             } else {
    //                 myChart.dispatchAction({
    //                     type: 'downplay',
    //                     seriesIndex: 0,
    //                     dataIndex: 0
    //                 });
    //             }
    //         });
    //
    //         myChart.on('mouseout', function(params) {
    //             myChart.dispatchAction({
    //                 type: 'highlight',
    //                 seriesIndex: 0,
    //                 dataIndex: 0
    //             });
    //         });
    //         myChart.dispatchAction({
    //             type: 'highlight',
    //             seriesIndex: 0,
    //             dataIndex: 0
    //         });
    //     }, 1000);
    //
    //     myChart.currentIndex = -1;
    //
    //     setInterval(function () {
    //         var dataLen = option.series[0].data.length;
    //         // 取消之前高亮的图形
    //         myChart.dispatchAction({
    //             type: 'downplay',
    //             seriesIndex: 0,
    //             dataIndex: myChart.currentIndex
    //         });
    //         myChart.currentIndex = (myChart.currentIndex + 1) % dataLen;
    //         // 高亮当前图形
    //         myChart.dispatchAction({
    //             type: 'highlight',
    //             seriesIndex: 0,
    //             dataIndex: myChart.currentIndex
    //         });
    //     }, 1000);
    //
    //     // 使用刚指定的配置项和数据显示图表。
    //     /*myChart.setOption(option);*/
    //     window.addEventListener("resize",function(){
    //         myChart.resize();
    //     });
    // }
    function ceshis2() {
        var myChart = echarts.init(document.getElementById('chart3'));

        option = {
            /*backgroundColor: '#000',*/
            "animation": true,
            "title": {
                /*"text": 24,*/
               /* "subtext": "沥青工",*/
                "x": "center",
                "y": "center",
                "textStyle": {
                    "color": "#fff",
                    "fontSize": 10,
                    "fontWeight": "normal",
                    "align": "center",
                    "width": "200px"
                },
                "subtextStyle": {
                    "color": "#fff",
                    "fontSize": 12,
                    "fontWeight": "normal",
                    "align": "center"
                }
            },
            "legend": {
                "width": "100%",
                "left": "center",
                "textStyle": {
                    "color": "#fff",
                    "fontSize": 12
                },
                "icon": "circle",
                "right": "0",
                "bottom": "0",
                "padding": [15, 20],
                "itemGap": 5,
                "data": ["食品车", "牵引车", "摆渡车", "油料车", "引导车", "行李车"]
            },
            "series": [{
                "type": "pie",
                "center": ["50%", "40%"],
                "radius": ["20%", "43%"],
                "color": ["#11b104",  "#9f17ff", "#0dcdff", "#1a46f6", "#d50808", "orange"],
                "startAngle": 135,
                "labelLine": {
                    "normal": {
                        "length": 15
                    }
                },
                "label": {
                    "normal": {
                        "formatter": "{b|{b}:}{per|{d}%} ",
                        "backgroundColor": "rgba(255, 147, 38, 0)",
                        "borderColor": "transparent",
                        "borderRadius": 4,
                        "rich": {
                            "a": {
                                "color": "#999",
                                "lineHeight": 12,
                                "align": "center"
                            },
                            "hr": {
                                "borderColor": "#aaa",
                                "width": "100%",
                                "borderWidth": 1,
                                "height": 0
                            },
                            "b": {
                                "color": "#b3e5ff",
                                "fontSize": 12,
                                "lineHeight": 20
                            },
                            "c": {
                                "fontSize": 14,
                                "color": "#eee"
                            },
                            "per": {
                                "color": "#fdf44e",
                                "fontSize": 10,
                                "padding": [5, 8],
                                "borderRadius": 2
                            }
                        },
                        "textStyle": {
                            "color": "#fff",
                            "fontSize": 16
                        }
                    }
                },
                "emphasis": {
                    "label": {
                        "show": true,
                        "formatter": "{b|{b}:}  {per|{d}%}  ",
                        "backgroundColor": "rgba(255, 147, 38, 0)",
                        "borderColor": "transparent",
                        "borderRadius": 4,
                        "rich": {
                            "a": {
                                "color": "#999",
                                "lineHeight": 22,
                                "align": "center"
                            },
                            "hr": {
                                "borderColor": "#aaa",
                                "width": "100%",
                                "borderWidth": 1,
                                "height": 0
                            },
                            "b": {
                                "color": "#fff",
                                "fontSize": 14,
                                "lineHeight": 33
                            },
                            "c": {
                                "fontSize": 14,
                                "color": "#eee"
                            },
                            "per": {
                                "color": "#FDF44E",
                                "fontSize": 14,
                                "padding": [5, 6],
                                "borderRadius": 2
                            }
                        }
                    }
                },
                "data": [{
                    "name": "食品车",
                    "value": 5
                }, {
                    "name": "牵引车",
                    "value": 24
                }, {
                    "name": "摆渡车",
                    "value": 21
                }, {
                    "name": "油料车",
                    "value": 12
                }, {
                    "name": "引导车",
                    "value": 13
                }, {
                    "name": "行李车",
                    "value": 13
                }]
            }, {
                "type": "pie",
                "center": ["50%", "40%"],
                "radius": ["15%", "14%"],
                "label": {
                    "show": false
                },
                "data": [{
                    "value": 78,
                    "name": "实例1",
                    "itemStyle": {
                        "normal": {
                            "color": {
                                "x": 0,
                                "y": 0,
                                "x2": 1,
                                "y2": 0,
                                "type": "linear",
                                "global": false,
                                "colorStops": [{
                                    "offset": 0,
                                    "color": "#9F17FF"
                                }, {
                                    "offset": 0.2,
                                    "color": "#01A4F7"
                                }, {
                                    "offset": 0.5,
                                    "color": "#FE2C8A"
                                }, {
                                    "offset": 0.8,
                                    "color": "#FEE449"
                                }, {
                                    "offset": 1,
                                    "color": "#00FFA8"
                                }]
                            }
                        }
                    }
                }]
            }]
        }

        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);
        myChart.currentIndex = -1;
        //myChart.setOption(option);
        //console.log(option.series[0].data[0]);
        setInterval(function () {
            var dataLen = option.series[0].data.length;
            // 取消之前高亮的图形
            myChart.dispatchAction({
                type: 'downplay',
                seriesIndex: 0,
                dataIndex: myChart.currentIndex
            });
            myChart.currentIndex = (myChart.currentIndex + 1) % dataLen;
            // 高亮当前图形
            myChart.dispatchAction({
                type: 'highlight',
                seriesIndex: 0,
                dataIndex: myChart.currentIndex
            });
        }, 1000);

        window.addEventListener("resize",function(){
            myChart.resize();
        });
    }
    function chart_leftBottom() {
        var myChart = echarts.init(document.getElementById('columnChart'));

        var colors = ['rgb(46, 199, 201)', 'rgb(90, 177, 239)', 'rgb(255,185,128)'];

        option = {
            color: colors,

            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross'
                },
                formatter: function(params) {
                    // 系列
                    let html = params[0].name + "<br>";

                    for (var i = 0; i < params.length; i++) {

                        // 获取每个系列对应的颜色值
                        html += '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;background-color:' + params[i].color + ';"></span>';

                        // 通过判断指定系列增加 % 符号
                        if (option.series[params[i].seriesIndex].type == "line") {
                            html += params[i].seriesName + ": " + params[i].value + "%<br>";
                        } else {
                            html += params[i].seriesName + ": " + params[i].value + "<br>";
                        }
                    }
                    return html;
                }
            },
            grid: {
                left: '12%',
                right: '5%'
            },
            toolbox: {
                feature: {
                    dataView: {
                        show: true,
                        readOnly: false
                    },
                    restore: {
                        show: true
                    },
                    saveAsImage: {
                        show: true
                    }
                }
            },
            legend: {
                textStyle: {
                    color: '#fff'
                },
                data: ['车辆数', '航班数']
            },
            // 缩放组件
            /*dataZoom: {
                type: 'slider'
            },*/
            xAxis: [{
                type: 'category',
                axisTick: {
                    alignWithLabel: false
                },
                axisLabel: {
                    formatter: '{value} ',
                    textStyle: {
                        color: "#ffffff" //X轴文字颜色
                    }
                },
                data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
            }],
            yAxis: [{
                type: 'value',
                name: '数量',
                min: 0,
                max: 1000,
                position: 'left',
                axisLine: {
                    lineStyle: {
                        color: colors[0]
                    }
                },
                axisLabel: {
                    formatter: '{value} '
                }
            }
            ,
                {
                    type: 'value',
                    name: '航班数',
                    min: 0,
                    max: 1000,
                    position: 'right',
                    offset: 80,
                    axisLine: {
                        lineStyle: {
                            color: colors[1]
                        }
                    },
                    axisLabel: {
                        formatter: '{value} '
                    }
                },
                {
                    // type: 'value',
                    // name: '平均值',
                    // min: 0,
                    // max: 25,
                    // position: '',
                    // axisLine: {
                    //     lineStyle: {
                    //         color: colors[2]
                    //     }
                    // },
                    // axisLabel: {
                    //     formatter: '{value} 万'
                    // }
                }
            ],
            series: [{
                name: '车辆数',
                type: 'bar',
                data: [200, 490, 70, 232, 256, 767, 950, 630, 326, 200, 120, 390],
                itemStyle: {
                    normal: {
                        barBorderRadius: 2
                    }
                }
            },
                {
                    barGap: '-50%', // 增加偏移量使重叠显示
                    name: '航班数',
                    type: 'bar',
                    yAxisIndex: 1,
                    data: [260, 590, 90, 264, 287, 707, 756, 980, 487, 188, 60, 230],
                    itemStyle: {
                        normal: {
                            barBorderRadius: 2
                        }
                    }
                },
                {
                    name: '平均值',
                    type: 'line',
                    yAxisIndex: 2,
                    // data: [2.0, 2.2, 3.3, 4.5, 6.3, 10.2, 20.3, 23.4, 23.0, 16.5, 12.0, 6.2],
                }
            ]
        };
        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);
        window.addEventListener("resize",function(){
            myChart.resize();
        });
    }
    function chart_rightBottom() {
        var myChart = echarts.init(document.getElementById('lineChart'));

        var option = {
            tooltip: {trigger: 'axis',axisPointer: {lineStyle: {color: '#fff'}}},
            legend: {
                icon: 'rect',
                itemWidth: 14,itemHeight: 5,itemGap:10,
                data: ['一级警告', '二级警告','三级警告'],
                right: '10px',top: '0px',
                textStyle: {fontSize: 12,color: '#fff'}
            },
            grid: {x:40,y:40,x2:10,y2:40},
            xAxis: [{
                type: 'category',boundaryGap: false,axisLine: {lineStyle: {color: '#57617B'}},axisLabel: {textStyle: {color:'#fff'}},
                data:[
                    "12月\n01号",
                    "12月\n02号",
                    "12月\n03号",
                    "12月\n04号",
                    "12月\n05号",
                    "12月\n06号",
                    "12月\n07号",
                    "12月\n08号",
                    "12月\n09号",
                    "12月\n10号",
                    "12月\n11号",
                    "12月\n12号",
                    "12月\n13号",
                    "12月\n14号",
                    "12月\n15号",
                    "12月\n16号",
                    "12月\n17号",
                    "12月\n18号",
                    "12月\n19号",
                    "12月\n20号",
                    "12月\n21号",
                    "12月\n22号",
                    "12月\n23号",
                    "12月\n24号",
                    "12月\n25号",
                    "12月\n26号",
                    "12月\n27号",
                    "12月\n28号",
                    "12月\n29号",
                    "12月\n30号"
                ]
            }],
            yAxis: [{
                type: 'value',
                axisTick: {
                    show: false
                },
                axisLine: {lineStyle: {color: '#57617B'}},
                axisLabel: {margin: 10,textStyle: {fontSize: 12},textStyle: {color:'#fff'},formatter:'{value}次'},
                splitLine: {lineStyle: {color: '#57617B'}}
            },{
                // type: 'value',
                // axisTick: {
                //     show: false
                // },
                // axisLine: {lineStyle: {color: '#57617B'}},
                // axisLabel: {margin: 10,textStyle: {fontSize: 12},textStyle: {color:'#fff'},formatter:'{value}个'},
                // splitLine: {show: false,lineStyle: {color: '#57617B'}}
            }],
            series: [
            //     {
            //     name: '受理时长',type: 'line',smooth: true,lineStyle: {normal: {width: 2}},
            //     yAxisIndex:0,
            //     areaStyle: {
            //         normal: {
            //             color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
            //                 offset: 0,
            //                 color: 'rgba(185,150,248,0.3)'
            //             }, {
            //                 offset: 0.8,
            //                 color: 'rgba(185,150,248,0)'
            //             }], false),
            //             shadowColor: 'rgba(0, 0, 0, 0.1)',
            //             shadowBlur: 10
            //         }
            //     },
            //     itemStyle: {normal: { color: '#B996F8'}},
            //     data: [
            //         "7.35",
            //         "7.31",
            //         "7.75",
            //         "7.45",
            //         "7.01",
            //         "6.46",
            //         "8.01",
            //         "6.18",
            //         "5.23",
            //         "7.08",
            //         "0.00",
            //         "0.00",
            //         "0.00",
            //         "0.00",
            //         "0.00",
            //         "7.29",
            //         "6.61",
            //         "6.79",
            //         "6.54",
            //         "6.87",
            //         "6.45",
            //         "6.10",
            //         "6.93",
            //         "6.85",
            //         "5.87",
            //         "8.98",
            //         "6.26",
            //         "6.95",
            //         "7.36",
            //         "0.00"
            //     ],
            // },
                {
                name: '一级警告',type: 'line',smooth: true,lineStyle: { normal: {width: 2}},
                yAxisIndex:0,
                areaStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: 'rgba(3, 194, 236, 0.3)'
                        }, {
                            offset: 0.8,
                            color: 'rgba(3, 194, 236, 0)'
                        }], false),
                        shadowColor: 'rgba(0, 0, 0, 0.1)',
                        shadowBlur: 10
                    }
                },
                itemStyle: {normal: {color: '#DA3914'}},
                data: [
                    "2",
                    "1",
                    "2",
                    "2",
                    "1",
                    "2",
                    "5",
                    "3",
                    "2",
                    "4",
                    "2",
                    "1",
                    "3",
                    "7",
                    "0",
                    "5",
                    "1",
                    "3",
                    "4",
                    "6",
                    "3",
                    "1",
                    "5",
                    "3",
                    "2",
                    "5",
                    "6",
                    "5",
                    "0",
                    "0"
                ]
            }, {
                name: '二级警告',type: 'line',smooth: true,lineStyle: {normal: {width: 2}},
                yAxisIndex:0,
                areaStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: 'rgba(218, 57, 20, 0.3)'
                        }, {
                            offset: 0.8,
                            color: 'rgba(218, 57, 20, 0)'
                        }], false),
                        shadowColor: 'rgba(0, 0, 0, 0.1)',
                        shadowBlur: 10
                    }
                },
                itemStyle: {normal: {color: '#E8BE31'}},
                data:[
                    "15",
                    "8",
                    "11",
                    "11",
                    "10",
                    "5",
                    "18",
                    "10",
                    "18",
                    "12",
                    "0",
                    "0",
                    "0",
                    "0",
                    "0",
                    "9",
                    "10",
                    "10",
                    "14",
                    "11",
                    "7",
                    "12",
                    "5",
                    "11",
                    "11",
                    "9",
                    "12",
                    "11",
                    "19",
                    "0"
                ]
            },{
                name: '三级警告',type: 'line',smooth: true,lineStyle: {normal: {width: 2}},
                yAxisIndex:0,
                areaStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: 'rgba(232, 190, 49, 0.3)'
                        }, {
                            offset: 0.8,
                            color: 'rgba(232, 190, 49, 0)'
                        }], false),
                        shadowColor: 'rgba(0, 0, 0, 0.1)',
                        shadowBlur: 10
                    }
                },
                itemStyle: {normal: {color: '#03C2EC'}},
                data: [
                    "22",
                    "17",
                    "20",
                    "20",
                    "18",
                    "13",
                    "16",
                    "17",
                    "16",
                    "16",
                    "7",
                    "5",
                    "2",
                    "1",
                    "5",
                    "17",
                    "18",
                    "17",
                    "22",
                    "19",
                    "16",
                    "11",
                    "22",
                    "19",
                    "17",
                    "16",
                    "20",
                    "19",
                    "27",
                    "10"
                ]
            }]


        };
        /*var myChart = echarts.init(document.getElementById('channel_handle_detail'));
        myChart.clear();
        if(data.handleTimeData.length>0){
            myChart.setOption(option);
        }else{
            noDataTip($("#channel_handle_detail"));
        }*/
        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);
        window.addEventListener("resize",function(){
            myChart.resize();
        });
    }
});








