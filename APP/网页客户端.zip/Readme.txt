###########介绍
本Demo为物体历史轨迹和轨迹预测的交互展示界面，共分为index和scene1两个页面，可以通过socket.io实现服务器与客户端之间数据、图片、视频的收发和展示。


###########环境依赖
node.js 	14.17.3
express	4.17.1	
socket.io	4.1.3	
socket.io-client	4.1.3	


1.用法
运行服务器server.js并设置好端口server.listen()，打开index.html或scene1.html并设置好连接端口 io('http://127.0.0.1:3000')。



2.文件介绍

##sever.js
服务器设置文件
 socket.on('data_obj', function (data) {}) 视角还原图数据接收
 socket.on('png0', function (data) {}) 摄像头视频数据接收
 socket.on('png1', function (data) {}) 深度图视频数据接收
 socket.on('pos1', function (data) {}) 轨迹俯视图数据接收


##scene1.js

场景一js文件
视频接收采用base64编码格式
socket.on('sendMsgA',data => handleData(data)); 视角还原图数据接收和处理
socket.on('sendPicture0',data => handlePicture0(data)); 摄像头视频数据接收
socket.on('sendPicture1',data => handlePicture1(data)); 深度图视频数据接收
socket.on('sendPicture2',data => handlePicture2(data)); 其他视频数据接收(位于scene1.html右下)
socket.on('sendTrack',data => handleTrack(data)); 轨迹俯视图数据接收
socket.emit('report',"") 向服务器发送信息

##notification.js
index.html右上角警告栏js文件

##notification.css
index.html右上角警告栏css文件

##echart.js
index.html图标js文件

##colliding.css(未使用)
碰撞动画演示


3.测试

client1.js为客户端测试js文件，可根据需要更改socket.emit内容。


4.开发

（1）在server.js中增加监听函数socket.on(ev: , listener:); ev:为发送端socket.emit 事件，listener为接收的数据
（2）将server.js中接收的数据通过函数io.sockets.emit(ev: , listener:); 向html文件发送
（3）html端通过监听函数socket.on(ev: , listener:);接收



