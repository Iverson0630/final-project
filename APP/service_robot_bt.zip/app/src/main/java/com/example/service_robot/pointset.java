package com.example.service_robot;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class pointset extends AppCompatActivity {
    EditText pointset;
    Button finish;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pointset);
        init_cont();
    }
    private void init_cont(){
        pointset = findViewById(R.id.输入点位);
        finish = findViewById(R.id.确定);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                switch (view.getId()){
                    case R.id.确定:
                        Intent intent=new Intent(pointset.this,MainActivity.class);
                        String num=pointset.getText().toString().trim();
                        intent.putExtra("data",num);
                        startActivity(intent);
                }
            }
        });
    }
}
