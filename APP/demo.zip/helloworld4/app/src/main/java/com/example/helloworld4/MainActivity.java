
package com.example.helloworld4;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private Button button_main;
    private Button button_main2;
    LocationManager manager;
    String[] requestPermissions = {
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.SEND_SMS
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView) findViewById(R.id.text1);
        manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        init_main();
        show_contact();
        jump_settingsd();
        ActivityCompat.requestPermissions(this, requestPermissions, 10086);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            textView.setText("no location permission");
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED ) {
            textView.setText("no sms permission");
            return;
        }

        manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 8, new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                updateLocation(location);
                String msg_content="经度为"+location.getLongitude()+"维度为"+location.getLatitude();
               // SendMsg(intent.getStringExtra("data"),msg_content);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        });
    }

    public void init_main() {
        button_main = findViewById(R.id.button_main_1);
        button_main.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                switch (view.getId()){
                    case R.id.button_main_1:
                        Intent intent=new Intent(MainActivity.this,ContactInfo.class);
                        startActivity(intent);
                        break;
                }
            }
        });
    }

    public void jump_settingsd() {
        button_main2 = findViewById(R.id.button_main_2);
        button_main2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                switch (view.getId()){
                    case R.id.button_main_2:
                        Intent intent=new Intent(MainActivity.this, bt_MainActivity.class);
                        startActivity(intent);
                        break;
                }
            }
        });
    }

    public void show_contact()
    {
        Intent intent=getIntent();
        TextView textView2=findViewById(R.id.text2);
        textView2.setText(intent.getStringExtra("data"));
    }
    public void updateLocation(Location location) {
        textView.setText("  ");
        textView.append("经度是:" + location.getLongitude());
        textView.append("\n纬度是:" + location.getLatitude());
        textView.append("\n高度:" + location.getAltitude());
        textView.append("\n方向:" + location.getBearing());
        textView.append("\n速度:" + location.getSpeed());
    }


    public void SendMsg(String number,String msg)
    {
        SmsManager sm = SmsManager.getDefault();
        List<String> sms = sm.divideMessage(msg);
        for (String smslist :sms){
            sm.sendTextMessage(number,null,msg,null,null);
        }
    }
}

