package com.example.helloworld4;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class ContactInfo extends AppCompatActivity {

    private EditText edit_car;
    private Button button_send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_input);
        init_cont();

    }

    private void init_cont(){
        edit_car = findViewById(R.id.contact2);
        button_send = findViewById(R.id.contact3);
        button_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                switch (view.getId()){
                    case R.id.contact3:
                        Intent intent=new Intent(ContactInfo.this,MainActivity.class);
                        String num=edit_car.getText().toString().trim();
                        intent.putExtra("data","紧急联系人号码："+num);
                        startActivity(intent);
                        break;
                }
            }
        });
    }


}
