package com.example.helloworld4;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class welcome extends AppCompatActivity {

    private SharedPreferences settings;
    private SharedPreferences.Editor editor;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcom);

        settings = getSharedPreferences("test", Context.MODE_PRIVATE);
        editor = settings.edit();

        int flag = settings.getInt("train_flag", 0);
        Log.d("flag！！！！！", String.valueOf(flag));
        if(flag==1){
            Intent intent=new Intent(welcome.this, bt_MainActivity.class);
            startActivity(intent);
        }

        else
        {
            Intent intent=new Intent(welcome.this, trainlog.class);
            startActivity(intent);
        }

    }
}