package com.example.helloworld4;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private Button button_main;
    LocationManager manager;
    private SharedPreferences settings;
    private AudioThread audioThread;
    Socket soc = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.text1);
        button_main = findViewById(R.id.btnexit);
        manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        settings = getSharedPreferences("test", Context.MODE_PRIVATE);
        init_main();
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_WIFI_STATE, Manifest.permission.INTERNET}, 10086);
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 10086);
        audioThread = new MainActivity.AudioThread();
        audioThread.start();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            textView.setText("no location permission");
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            textView.setText("no sms permission");
            return;
        }


        manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 8, new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                Log.d("*******", "开始获取位置");
                updateLocation(location);
                String socket_content = "经度为" + location.getLongitude() + "纬度为" + location.getLatitude();
                new ConnectionThread(socket_content).start();
                String msg_content = "【救命宝】提示您,您的好友正在发起紧急求助，可能需要您的帮助";//,访问以下链接获取详细信息";
              //  String msg_content2="http://38.55.216.131:59735/interface/index.html?_ijt=l0ap0esr58msaps9q00vel7jv0";
                Log.d("*******", "socket连接成功");
                int contact_count = settings.getInt("contact_countv2", 0);
                for (int i = 1; i < contact_count + 1; i++) {
                    String tmp = settings.getString("contact_v2" + i, null);

                    SendMsg(tmp, msg_content);
             //       SendMsg(tmp, msg_content2);
                }
                Toast.makeText(getApplicationContext(), "已同时为" + contact_count + "名紧急联系人发送求助短信", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        });
    }



    public void init_main() {
        button_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.btnexit:
                        Intent intent = new Intent(MainActivity.this, bt_MainActivity.class);
                        startActivity(intent);
                        break;
                }
            }
        });
    }

    public void updateLocation(Location location) {
        textView.setText("");
        textView.append("经度是:" + location.getLongitude());
        textView.append("\n纬度是:" + location.getLatitude());
        textView.append("\n高度:" + location.getAltitude());
        textView.append("\n方向:" + location.getBearing());
        textView.append("\n速度:" + location.getSpeed());
    }


    public void SendMsg(String number, String msg) {
        SmsManager sm = SmsManager.getDefault();
        List<String> sms = sm.divideMessage(msg);
        for (String s1 : sms) {
            sm.sendTextMessage(number, null, s1, null, null);
        }
    }

    class ConnectionThread extends Thread {
        String message = null;
        public ConnectionThread(String msg) {
            message = msg;
        }

        @Override
        public void run() {
            try {
                Log.d("******socket*******", "new socket");
                soc = new Socket("ifast3.vipnps.vip", 29249);
                OutputStream os = soc.getOutputStream();//字节输出流
                PrintWriter pw = new PrintWriter(os);//将输出流包装为打印流
                pw.write(message);
                pw.flush();
                soc.shutdownOutput();//关闭输出流
            } catch (IOException e) {
                //    Toast.makeText(getApplicationContext(), "指令发送失败", Toast.LENGTH_SHORT).show();
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
    }

    private class AudioThread extends Thread {


        private int audioSource = MediaRecorder.AudioSource.MIC;
        // 设置音频采样率，44100是目前的标准，但是某些设备仍然支持22050，16000，11025
        private int sampleRateInHz = 44100;
        // 设置音频的录制的声道CHANNEL_IN_STEREO为双声道，CHANNEL_CONFIGURATION_MONO为单声道
        private int channelConfig = AudioFormat.CHANNEL_IN_STEREO;
        // 音频数据格式:PCM 16位每个样本。保证设备支持。PCM 8位每个样本。不一定能得到设备支持。
        private int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
        // 缓冲区字节大小
        private int bufferSizeInBytes = 0;
        private AudioRecord audioRecord;
        private boolean isRecord = false;// 设置正在录制的状态
        //AudioName裸音频数据文件
        private static final String AudioName = "/sdcard/love.raw";
        //NewAudioName可播放的音频文件
        private static final String NewAudioName = "/sdcard/new.wav";
        Button btnstop;

        public void run() {

            btnstop = findViewById(R.id.btnstop);
            btnstop.setOnClickListener(new View.OnClickListener() {
                                               @Override
                                               public void onClick(View view) {
                                                   switch (view.getId()) {
                                                       case R.id.btnstop:
                                                           close();
                                                           sendRecord();
                                                           Log.d("**********", "stopRecord");
                                                           break;
                                                   }
                                               }
                                           });

            creatAudioRecord();
            try {
                startRecord();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private void sendRecord()
        {
            File recordFile = new File(NewAudioName);
            long length = recordFile.length();
            Log.d("********","length"+length);
            byte[] data = new byte[(int)length];
            try {
                FileInputStream in = new FileInputStream(NewAudioName);
                while (in.read(data) != -1) {
                    new sendRecordThread(data).start();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        private void close() {
            if (audioRecord != null) {
                Log.d("**********", "stopRecord");
                System.out.println("stopRecord");
                isRecord = false;//停止文件写入
                audioRecord.stop();
                audioRecord.release();//释放资源
                audioRecord = null;
            }
        }
       @SuppressLint("MissingPermission")
        private void creatAudioRecord() {
            // 获得缓冲区字节大小
            bufferSizeInBytes = AudioRecord.getMinBufferSize(sampleRateInHz,
                    channelConfig, audioFormat);
            // 创建AudioRecord对象

        }

        public void startRecord() throws IOException {
            if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                Log.d("**********", "无录音权限");
                return;
            }
            audioRecord = new AudioRecord(audioSource, sampleRateInHz,
                    channelConfig, audioFormat, bufferSizeInBytes);
            audioRecord.startRecording();
            // 让录制状态为true
            isRecord = true;
            //建立录音传输
            new Thread(new AudioRecordThread()).start();
        }
        class AudioRecordThread implements Runnable {
            @Override
            public void run() {
                writeDateTOFile();//往文件中写入裸数据
                copyWaveFile(AudioName, NewAudioName);//给裸数据加上头文件
            }
        }
        public void writeDateTOFile() {
            // new一个byte数组用来存一些字节数据，大小为缓冲区大小
            byte[] audiodata = new byte[bufferSizeInBytes];
            FileOutputStream fos = null;
            int readsize = 0;
            try {
                File file = new File(AudioName);
                if (file.exists()) {
                    file.delete();
                }
                fos = new FileOutputStream(file);// 建立一个可存取字节的文件
                Log.d("**********", "createed");
            } catch (Exception e) {

                e.printStackTrace();
            }
            while (isRecord == true) {
                readsize = audioRecord.read(audiodata, 0, bufferSizeInBytes);
                if (AudioRecord.ERROR_INVALID_OPERATION != readsize) {
                    try {
                        fos.write(audiodata);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            try {
                fos.close();// 关闭写入流
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        public void copyWaveFile(String inFilename, String outFilename) {
            FileInputStream in = null;
            FileOutputStream out = null;
            long totalAudioLen = 0;
            long totalDataLen = totalAudioLen + 36;
            long longSampleRate = sampleRateInHz;
            int channels = 2;
            long byteRate = 16 * sampleRateInHz * channels / 8;
            byte[] data = new byte[bufferSizeInBytes];
            try {
                in = new FileInputStream(inFilename);
                out = new FileOutputStream(outFilename);
                totalAudioLen = in.getChannel().size();
                totalDataLen = totalAudioLen + 36;
                WriteWaveFileHeader(out, totalAudioLen, totalDataLen,
                        longSampleRate, channels, byteRate);
                while (in.read(data) != -1) {
                    out.write(data);
                //    OutputStream os=soc.getOutputStream();//字节输出流
                //    os.write(data);
                //    os.flush();
                }
                in.close();
                out.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        public void WriteWaveFileHeader(FileOutputStream out, long totalAudioLen,
                                         long totalDataLen, long longSampleRate, int channels, long byteRate)
                throws IOException {
            byte[] header = new byte[44];
            header[0] = 'R'; // RIFF/WAVE header
            header[1] = 'I';
            header[2] = 'F';
            header[3] = 'F';
            header[4] = (byte) (totalDataLen & 0xff);
            header[5] = (byte) ((totalDataLen >> 8) & 0xff);
            header[6] = (byte) ((totalDataLen >> 16) & 0xff);
            header[7] = (byte) ((totalDataLen >> 24) & 0xff);
            header[8] = 'W';
            header[9] = 'A';
            header[10] = 'V';
            header[11] = 'E';
            header[12] = 'f'; // 'fmt ' chunk
            header[13] = 'm';
            header[14] = 't';
            header[15] = ' ';
            header[16] = 16; // 4 bytes: size of 'fmt ' chunk
            header[17] = 0;
            header[18] = 0;
            header[19] = 0;
            header[20] = 1; // format = 1
            header[21] = 0;
            header[22] = (byte) channels;
            header[23] = 0;
            header[24] = (byte) (longSampleRate & 0xff);
            header[25] = (byte) ((longSampleRate >> 8) & 0xff);
            header[26] = (byte) ((longSampleRate >> 16) & 0xff);
            header[27] = (byte) ((longSampleRate >> 24) & 0xff);
            header[28] = (byte) (byteRate & 0xff);
            header[29] = (byte) ((byteRate >> 8) & 0xff);
            header[30] = (byte) ((byteRate >> 16) & 0xff);
            header[31] = (byte) ((byteRate >> 24) & 0xff);
            header[32] = (byte) (2 * 16 / 8); // block align
            header[33] = 0;
            header[34] = 16; // bits per sample
            header[35] = 0;
            header[36] = 'd';
            header[37] = 'a';
            header[38] = 't';
            header[39] = 'a';
            header[40] = (byte) (totalAudioLen & 0xff);
            header[41] = (byte) ((totalAudioLen >> 8) & 0xff);
            header[42] = (byte) ((totalAudioLen >> 16) & 0xff);
            header[43] = (byte) ((totalAudioLen >> 24) & 0xff);
            out.write(header, 0, 44);

        }
    }

    class sendRecordThread extends Thread {
        byte[] data1 = null;
        public sendRecordThread(byte[] data ) {
            data1 = data;
        }

        @Override
        public void run() {
            try {
                soc = new Socket("ifast3.vipnps.vip", 29249);
                OutputStream os = soc.getOutputStream();//字节输出流
                os.write(data1);
                os.flush();
            } catch (IOException e) {
                //    Toast.makeText(getApplicationContext(), "指令发送失败", Toast.LENGTH_SHORT).show();
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
    }
}
