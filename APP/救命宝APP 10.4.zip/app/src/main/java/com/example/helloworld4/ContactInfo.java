package com.example.helloworld4;
import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class ContactInfo extends AppCompatActivity {
    private  int contact_count;
    private EditText edit_car;
    private ImageButton button_send,button_add,button_remove;
    private TextView cont_show;

    private SharedPreferences settings;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.contact_input);
        settings = getSharedPreferences("test", Context.MODE_PRIVATE);
        editor = settings.edit();
        cont_show = findViewById(R.id.cont_set);
        show_contact();
        init_cont();
    }

    private void show_contact() {
        contact_count = settings.getInt("contact_countv2", 0);
        Log.d("111111", "******count*******" + contact_count);
        for (int i = 1; i < contact_count + 1; i++) {
            String tmp = settings.getString("contact_v2" + i, null);
            cont_show.append("联系人" + i + ":  " + tmp + "\n");
        }
    }
    private void init_cont() {
            edit_car = findViewById(R.id.cont_input);
            button_add = findViewById(R.id.cont_add);
            button_send = findViewById(R.id.cont_jump);
            button_remove = findViewById(R.id.cont_delete);
            button_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    switch (view.getId()) {
                        case R.id.cont_add:
                            contact_count++;
                            String num = edit_car.getText().toString().trim();
                            editor.putString("contact_v2" + contact_count, num);
                            editor.putInt("contact_countv2", contact_count);
                            editor.commit();
                            Toast.makeText(getApplicationContext(), "添加联系人成功", Toast.LENGTH_SHORT).show();
                            cont_show.append("联系人" + contact_count + ":  " + num + "\n");
                            Log.d("111111", "******输入号码为*******" + num);
                    }
                }
            });
        button_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                switch (view.getId()){
                    case R.id.cont_jump:
                        Intent intent=new Intent(ContactInfo.this,bt_MainActivity.class);
                      //  intent.putExtra("data",num);
                        startActivity(intent);

                }
            }
        });

        button_remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                switch (view.getId()){
                    case R.id.cont_delete:
                       editor.clear();
                       editor.commit();
                       cont_show.setText(null);


                }
            }
        });
    }

}
