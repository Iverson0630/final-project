package com.example.helloworld4;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class copyright extends AppCompatActivity {

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.copyright);
        Button back = findViewById(R.id.cp_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.cp_back:
                        Intent intent = new Intent(copyright.this, bt_MainActivity.class);
                        startActivity(intent);
                }

            }
        });
    }
}